#!/bin/bash
CWD=$(cd "$(dirname $0)";pwd)
"$CWD"/easynvs stop
"$CWD"/easynvs uninstall 