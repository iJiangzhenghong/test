define({
  "name": "EasyNVS",
  "title": "EasyNVS 接口文档",
  "order": [
    "dev",
    "sys",
    "Login",
    "Logout",
    "GetUserInfo",
    "ModifyPassword",
    "GetServerInfo"
  ],
  "version": "2.0.0",
  "description": "EasyNVR Manager System",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-11-02T02:27:25.190Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
