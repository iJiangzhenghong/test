define({ "api": [
  {
    "type": "Any",
    "url": "/nvc/:device_id/...",
    "title": "设备 API 调用",
    "group": "nvc",
    "description": "<p>对于接入的 EasyNVR 操作接口, 参考 EasyNVR API 接口文档, 通过 EasyNVS 操作 EasyNVR 时, 只需针对 EasyNVR 接口添加 URL 前辍 <code>/nvc/${device_id}</code></p>",
    "version": "0.0.0",
    "filename": "routers/proxy.go",
    "groupTitle": "设备接口",
    "name": "AnyNvcDevice_id",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/getserverinfo",
    "title": "获取平台运行信息",
    "group": "sys",
    "name": "GetServerInfo",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Authorization",
            "description": "<p>授权对象</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Hardware",
            "description": "<p>硬件信息</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "InterfaceVersion",
            "description": "<p>接口版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "IsDemo",
            "description": "<p>演示版本</p>"
          },
          {
            "group": "200",
            "type": "Boolean",
            "optional": false,
            "field": "APIAuth",
            "description": "<p>直播页面鉴权</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "RemainDays",
            "description": "<p>剩余授权时间(天)</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "RunningTime",
            "description": "<p>运行时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ServerTime",
            "description": "<p>系统时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "StartUpTime",
            "description": "<p>启动时间</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Server",
            "description": "<p>软件信息</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ChannelCount",
            "description": "<p>通道数</p>"
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "VersionType",
            "description": "<p>版本类型</p>"
          }
        ]
      }
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/userInfo",
    "title": "获取当前登录用户信息",
    "group": "sys",
    "name": "GetUserInfo",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": ""
          },
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Name",
            "description": "<p>用户名</p>"
          },
          {
            "group": "200",
            "type": "String[]",
            "optional": true,
            "field": "roles",
            "description": "<p>角色列表</p>"
          }
        ]
      }
    }
  },
  {
    "type": "get",
    "url": "/api/v1/login",
    "title": "登录",
    "group": "sys",
    "name": "Login",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "username",
            "description": "<p>用户名</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码(经过md5加密,32位长度,不带中划线,不区分大小写)</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Token",
            "description": ""
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"Token\":\"mDC4tu-ig\", \"TokenTimeout\":604800}\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/logout",
    "title": "登出",
    "group": "sys",
    "name": "Logout",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  },
  {
    "type": "get",
    "url": "/api/v1/modifypassword",
    "title": "修改密码",
    "group": "sys",
    "name": "ModifyPassword",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "oldpassword",
            "description": "<p>旧密码, MD5密文</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "newpassword",
            "description": "<p>新密码, MD5密文</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "200": [
          {
            "group": "200",
            "type": "String",
            "optional": false,
            "field": "Token",
            "description": "<p>更新后的Token</p>"
          },
          {
            "group": "200",
            "type": "Number",
            "optional": false,
            "field": "TokenTimeout",
            "description": "<p>Token 超时(秒)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200\n{\"Token\":\"mDC4tu-ig\", \"TokenTimeout\":604800}\nSet-Cookie: token=mDC4tu-ig; Path=/; Expires=Thu, 15 Nov 2018 03:13:26 GMT; Max-Age=604800; HttpOnly",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口"
  },
  {
    "type": "get",
    "url": "/api/v1/restart",
    "title": "重启服务",
    "group": "sys",
    "name": "Restart",
    "version": "0.0.0",
    "filename": "routers/sys_api.go",
    "groupTitle": "系统接口",
    "success": {
      "examples": [
        {
          "title": "成功",
          "content": "HTTP/1.1 200 OK",
          "type": "json"
        }
      ]
    }
  }
] });
